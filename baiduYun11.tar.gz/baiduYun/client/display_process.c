#include "head.h"
//process为进度的百分比，取值0~100，last_char_count为上一次显示进度条所用到的字符个数
int display_progress(int progress,int last_char_count){
	int i=0;
	//把上次显示的进度条信息全部清空
	for(i=0;i<last_char_count;i++)
		printf("\b");
	for(i=0;i<progress;i++){
		printf("#");
	}
	printf(">>");
	//输出空格截止到104的位置
	for(i+=2;i<104;i++){
		printf(" ");
	}
	i=i+printf("[%d%%]",progress);
	fflush(stdout);
	return i;

}
