#include "head.h"

void user_op(int sfd){
	printf("\t\t\t--------1 登陆-----------\n");
	printf("\t\t\t--------2 注册-----------\n");
	printf("\t\t\t---请选择你要操作的方式:");
	int i=0;
	while(1){
		scanf_num(&i);
		if(i>0&&i<3){
			break;
		}else{
			printf("请输入正确的操作数\n");
		}
	}
	int ret=send(sfd,&i,4,0);
	char buf[100]={0};
	char name[20]={0};
	switch(i){
		case 1:user_login(sfd,name);
			   //			   printf("测试\n");
			   recv(sfd,&i,4,0);
			   printf("%d\n",i);
			   if(i==1){
				   printf("验证成功！\n");
			   }
			   else if(i==0){
				   printf("管理员登陆成功\n");
				   manager(sfd,name);
			   }
			   else{
				   printf("验证失败！\n");
				   user_op(sfd);
			   }
			   break;
		case 2:user_register(sfd);
			   recv(sfd,&i,4,0);
			   if(i==1){

				   recv(sfd,buf,sizeof(buf),0);
				   printf("注册成功\n");
			   }else{
				   if(i==-2){
					   printf("该用户已存在\n");
				   }
				   printf("注册失败\n");
				   user_op(sfd);
			   }
			   bzero(buf,sizeof(buf));
			   break;
	}
}
int sock_init(char *argv[]){
	int sfd=socket(AF_INET,SOCK_STREAM,0);
	struct sockaddr_in sock;
	bzero(&sock,sizeof(sock));
	sock.sin_family=AF_INET;
	printf("ip:%s\n,port:%s\n",argv[1],argv[2]);
	sock.sin_port=htons(atoi(argv[2]));
	sock.sin_addr.s_addr=inet_addr(argv[1]);
	int i=0;
	while(connect(sfd,(struct sockaddr *)&sock,sizeof(struct sockaddr))==-1){
		perror("connect");
		i++;
		if(i>7)
		{
			close(sfd);
			return -1;
		}
	}
	printf("connect success\n");
	return sfd;
}
void help(){
	printf("\t\t\t--------help----------\n");
	printf("\t\t\tls     查看当前目录\n");
	printf("\t\t\tcd     进入目录\n");
	printf("\t\t\tmkdir  创建目录\n");
	printf("\t\t\tputs   上传文件\n");
	printf("\t\t\tgets   下载文件\n");
	printf("\t\t\tremove  删除文件\n");
	printf("\t\t\tpwd     查看当前所在位置\n");
	printf("\t\t\tsearch 查找文件\n");
	printf("\t\t\tcap    查看当前使用容量\n");
}
char * itoa(int temp,char * temp1)
{
	char temp2[6]={0};
	int i;
	printf("port:%d\n",temp);
	for(i=0;temp/10;)
	{
		int c=temp%10;
		temp2[i++]=c+48;
		temp/=10;
	}
	temp2[i]=temp+48;
	for(int j=0;j<=i;j++)
	{
		temp1[j]=temp2[i-j];
	}
	printf("%s\n",temp1);
	return temp1;
}
int main(int argc,char *argv[]){
	if(3!=argc){
		printf("args error");
		return -1;
	}
	const char *orderlist[]={"cd","ls","puts","gets","remove","pwd","mkdir","search","cap"};

	int sfd=sock_init(argv);
	int ret;
	char order[50];
	char temp[10];
	char temp1[60];
	char msg[1000];
	int i=0;
	int j=0;
	//	printf("进入验证阶段\n");
	user_op(sfd);
	//	printf("以出验证阶段\n");
	fflush(stdout);
	int orderlen=0;
	while(1){
		bzero(order,sizeof(order));
		bzero(temp,sizeof(temp));
		bzero(temp1,sizeof(temp1));
		bzero(msg,sizeof(msg));
		ret=read(0,order,sizeof(order)-1);
		if(0>=ret){
			perror("read");
			goto end;
		}
		for(i=0;i<strlen(order)&&order[i]!=' '&&order[i]!='\n';i++){
			temp[i]=order[i];
		}
		i++;
		for(j=0;i<strlen(order)&&order[i]!='\n';i++,j++){
			temp1[j]=order[i];
		}
		temp1[j]='\0';
		if(strlen(temp1)==0){
			temp1[0]='.';
			temp1[1]='\0';
		}
		for(j=0;j<9;j++){
			if(strcmp(temp,orderlist[j])==0){
				sprintf(order,"%d %s",j,temp1);
				orderlen=strlen(order);
				ret=send(sfd,&orderlen,4,0);
				ret=send(sfd,order,strlen(order),0);
				if(ret<=0){
					goto end;
				}
				break;
			}
		}
		//	ret=recv(sfd,msg,sizeof(msg),0);
		if(j>8){
			printf("无此命令\n");
			help();
		}
		else if(j!=2&&j!=3&&j!=7&&j!=8){
			ret=recv(sfd,msg,sizeof(msg),0);
			printf("%s\n",msg);

		}
		else if(j==8){
			bzero(msg,sizeof(msg));
			ret=recv(sfd,msg,sizeof(msg),0);
			long useCapacity=0;//使用空间
			long Capacity=0;//总空间
			sscanf(msg,"%ld %ld",&useCapacity,&Capacity);//字符串转long int
			double percent=((double)useCapacity*100)/Capacity;//计算百分比
			int c_cap=(int)(Capacity/(1024*1024*1024));//转换单位
			double u_cap=useCapacity;
			int i=0;
			while((u_cap/1024)>1){
				u_cap/=1024;
				i++;
			}
			if(i==0){
				printf("空间使用情况：%dB/%dGB \n百分比：%2.2f %%\n",(int)u_cap,c_cap,percent);	
			}else if(i==1){
				printf("空间使用情况：%2.2fkB/%dGB \n百分比：%2.2f %%\n",u_cap,c_cap,percent);	
			}else if(i==2){
				printf("空间使用情况：%2.2fMB/%dGB \n百分比：%2.2f %%\n",u_cap,c_cap,percent);		
			}else{
				printf("空间使用情况：%2.2fGB/%dGB \n百分比：%2.2f %%\n",u_cap,c_cap,percent);	
			}	
		}
		else if(j==2){
			//	ret=tran_file(sfd,".",temp1);
			char fileflag='Y';
			int fd=open(temp1,O_RDWR);
			if(-1==fd)
			{
				perror("open");
				fileflag='N';
				send(sfd,&fileflag,1,0);
			}else{
				send(sfd,&fileflag,1,0);
				int new_port=0;
				tfile t;
				strcpy(t.path,".");
				strcpy(t.order,temp1);
				recv(sfd,&new_port,4,0);
				printf("new_port:%d\n",new_port);
				char temp1[6]={0};
				char *temp[]={"0",argv[1],itoa(new_port,temp1)};
				int new_fd=sock_init(temp);
				pthread_t pid;
				t.sfd=new_fd;
				t.fd=fd;
				pthread_create(&pid,NULL,thread_func_tran_file,(void *)&t);	
				printf("传输中..........\n");
			}
		}else if(j==3){
			ret=gets_file(sfd,temp1);
			if(ret==0){
				printf("文件传输成功！\n");
			}	
			ret=6;	
		}else{
			int templen=0;
			ret=recv(sfd,&templen,4,0);
			if(0>=ret){
				printf("查找失败！");
				goto end;
			}
			ret=0;
			while(ret<templen){
				ret=recv(sfd,msg+ret,templen-ret,0);
				ret+=ret;
			}
			printf("%s\n",msg);

		}

		if(ret<0){
			goto end;
		}
	}
end:
	close(sfd);
}
