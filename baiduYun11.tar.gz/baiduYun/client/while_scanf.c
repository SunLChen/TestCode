#include "head.h"

void scanf_num(int *num){
	int ret;
	while(1){
		ret=scanf("%d",num);
		char c;
		while(scanf("%c",&c)==1&&c!='\n'){
			ret=0;
		}
		if(ret==0){
			printf("请输入正确的操作数！\n");
		}
		if(ret==1){
			break;
		}
	}
}
