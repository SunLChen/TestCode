#include "head.h"
int calculate_md5sum(char *filename,unsigned char *md5)
{
	//open file for calculating md5sum
	FILE *file_ptr;
	file_ptr = fopen(filename, "r");
	if (file_ptr==NULL)
	{
		perror("Error opening file");
		fflush(stdout);
		return -1;
	}
	int n;
	MD5_CTX c;
	char buf[512];
	ssize_t bytes;
	unsigned char out[MD5_DIGEST_LENGTH];
	MD5_Init(&c);
	do
	{
		bytes=fread(buf, 1, 512, file_ptr);
		MD5_Update(&c, buf, bytes);
	}while(bytes > 0);

	MD5_Final(out, &c);
	sprintf(md5,"%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X", out[0],out[1],out[2],out[3],out[4],out[5],out[6],out[7],out[8],out[9],out[10],out[11],out[12],out[13],out[14],out[15]);
	fseek(file_ptr,0,0);
	fclose(file_ptr);
	return 0;
}

