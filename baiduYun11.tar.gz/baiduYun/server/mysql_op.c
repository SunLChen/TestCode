#include "head.h"

int proCatalog(MYSQL *conn,char *path){
	char query[200]="select * from fileTable where path='";
	sprintf(query,"%s%s%s",query,path,"'");
	MYSQL_RES *res;
	MYSQL_ROW row;
	int procatalog=0;
	int t=mysql_query(conn,query);
	if(t)
	{
		printf("Error making query:%s\n",mysql_error(conn));
	}else{
		res=mysql_use_result(conn);
		if(res)
		{
			while((row=mysql_fetch_row(res))!=NULL)
			{
				procatalog=atoi(row[0]);
			}
		}
		mysql_free_result(res);
	}
	return procatalog;
}
int getMD5(MYSQL *conn,char *md5,pfTab tab){
	
	char query[200]="select * from fileTable where md5='";
	sprintf(query,"%s%s%s",query,md5,"';");
	MYSQL_RES *res;
	MYSQL_ROW row;
	int procatalog=0;
	int t=mysql_query(conn,query);
	if(t)
	{
		printf("Error making query:%s\n",mysql_error(conn));
	}else{
		res=mysql_use_result(conn);
		if(res)
		{
			while((row=mysql_fetch_row(res))!=NULL)
			{
				strcpy(tab->user,row[5]);
				strcpy(tab->path,row[6]);
				mysql_free_result(res);
				return 1;
			}
		}
		mysql_free_result(res);
		return 0;
	}
}

int findSameName(MYSQL *conn, char *fileName,char *path){
	
	char query[200]="select * from fileTable where fileName='";
	sprintf(query,"%s%s%s%s/%s%s",query,fileName,"' and path='",path,fileName,"';");
	MYSQL_RES *res;
	MYSQL_ROW row;
	int procatalog=0;
	int t=mysql_query(conn,query);
	if(t)
	{
		printf("Error making query:%s\n",mysql_error(conn));
	}else{
		res=mysql_use_result(conn);
		if(res)
		{
			while((row=mysql_fetch_row(res))!=NULL)
			{
				return 2;
			}
		}
		mysql_free_result(res);
		return 0;
	}
}

void getsCapacity(MYSQL *conn,char * user,long capacity[]){
	char query[200]="select useCapacity,capacity from userTable where username='";
//	printf("进来了2\n");
	sprintf(query,"%s%s'",query,user);
	MYSQL_RES *res;
	MYSQL_ROW row;
	int procatalog=0;
	int t=mysql_query(conn,query);
	if(t)
	{
		printf("Error making query:%s\n",mysql_error(conn));
	}else{
		res=mysql_use_result(conn);
		if(res)
		{
			while((row=mysql_fetch_row(res))!=NULL)
			{
				capacity[0]=atol(row[0]);
				capacity[1]=atol(row[1]);
			}
		}
		mysql_free_result(res);
	}	
}

int putsFile(MYSQL *conn,int proCatalogue,char *fileName,char *user,char *md5,char *path,long fileLen,long *capacity){
	char query1[200]="insert into fileTable(proCatalogue,fileName,fileType,md5,user,path) values(";
	sprintf(query1,"%s%d%s%s%s%s%s%s%s%s%s%s/%s%s",query1,proCatalogue,",","'",fileName,"',","'f','",md5,"','",user,"','",path,fileName,"')");
//	puts(query1);
	long num=capacity[0]+fileLen;
	char query[100]="update userTable set useCapacity=";

	sprintf(query,"%s%ld where username='%s';",query,num,user);
	
	int t=mysql_query(conn,query1);
	mysql_query(conn,query);
	if(t)
	{
		printf("Error making query:%s\n",mysql_error(conn));
		return -1;
	}else{
		printf("insert success\n");
	}
}
int remove_file(MYSQL *conn,char *filename,char *path,char *user){
	char query[200]="delete from fileTable where fileName='";
	sprintf(query,"%s%s%s%s%s",query,filename,"' and path='",path,"';");
	long capacity[2]={0};
	getsCapacity(conn,user,capacity);
	struct stat statBuf;
	int fd=open(path,O_RDWR);
	if(-1==fd){
		perror("open");
	}
	fstat(fd,&statBuf);
	close(fd);
	long num=capacity[0]-statBuf.st_size;
	char result[300]={0};	
	char query1[100]="update userTable set useCapacity=";
	sprintf(query1,"%s%ld where username='%s';",query1,num,user);
	MysqlU(conn,query1,result);
	char buf[100]={0};
//	puts(query);	
	int t=mysql_query(conn,query);
	if(t)
	{
		printf("Error making query:%s\n",mysql_error(conn));
		return -1;
	}else{
		printf("delete success\n");
	}
//	strcpy(buf,"删除成功");
//	send(sfd,buf,strlen(buf),0);
	return 0;
}
void searchFile(MYSQL *conn,int sfd,char *filename,char *user){

	char result[1000]={0};
	char query[200]="select * from fileTable where filename like '";
	sprintf(query,"%s%s%s%s%s%s",query,"%",filename,"%' and user='",user,"';");
	MYSQL_RES *res;
	MYSQL_ROW row;
	int procatalog=0;
	int t=mysql_query(conn,query);
	if(t)
	{
		printf("Error making query:%s\n",mysql_error(conn));
	}else{
		res=mysql_use_result(conn);
		if(res)
		{
			while((row=mysql_fetch_row(res))!=NULL)
			{
				sprintf(result,"%s%s\n",result,row[6]);
			}
		}
		mysql_free_result(res);
	}
	int ret=0;
	int len=strlen(result);
	send(sfd,&len,4,0);
	if(len>0)
		while(ret<len){
			ret=send(sfd,result+ret,strlen(result)-ret,0);
			ret+=ret;
		}
}
void Mysqlop(MYSQL *conn,char *query,char *result){
	MYSQL_RES *res;
	MYSQL_ROW row;
	int procatalog=0;
	int t=mysql_query(conn,query);
	if(t)
	{
		printf("Error making query:%s\n",mysql_error(conn));
	}else{
		res=mysql_use_result(conn);
		if(res)
		{
			while((row=mysql_fetch_row(res))!=NULL)
			{
				sprintf(result,"%s%4s  %6s  %4s    %12sB    %12sB    %20s\n",result,row[0],row[1],row[4],row[5],row[6],row[7]);
			}
		}
		mysql_free_result(res);
	}
}
void MysqlD(MYSQL *conn,char *query,char *query2,char *result){
	MYSQL_RES *res;
	MYSQL_ROW row;
	int procatalog=0;
	int t=mysql_query(conn,query);
	if(!t){
		t=mysql_query(conn,query2);
		strcpy(result,"删除成功！！");
	}else{
		strcpy(result,"删除失败！！");
	}
}
void MysqlU(MYSQL *conn,char *query,char *result){
	MYSQL_RES *res;
	MYSQL_ROW row;
	int procatalog=0;
	int t=mysql_query(conn,query);
	if(!t){
		strcpy(result,"修改成功！！");
	}else{
		strcpy(result,"修改失败！！");
	}
}
void updateUserCapacity(int sfd,MYSQL *conn){
	int n=0;
	int id=0;
	recv(sfd,&id,4,0);
	recv(sfd,&n,4,0);
	char result[100]={0};
	long num=2147483648*n;
	char query[100]="update userTable set capacity=";
	sprintf(query,"%s%ld where userId='%d';",query,num,id);
	MysqlU(conn,query,result);
	int len=strlen(result);
	int ret=0;
	int sum=0;
	send(sfd,&len,4,0);
	while(sum<len){
		ret=send(sfd,result+sum,len-sum,0);
		sum+=ret;
	}
}
void deleteUser(int sfd,MYSQL *conn)
{
	char name[20]={0};
	char path[400];
	recv(sfd,&name,sizeof(name),0);
	char result[60]={0};
	sprintf(path,"./home/%s",name);
	char query[200]="delete from fileTable where user='";
	sprintf(query,"%s%s'",query,name);
	char query1[200]="delete from userTable where username='";
	sprintf(query1,"%s%s'",query1,name);
	MysqlD(conn,query,query1,result);
	remove_dir(path);
	printf("path:%s\n",path);
	int len=strlen(result);
	int ret=0;
	int sum=0;
	send(sfd,&len,4,0);
	while(sum<len){
		ret=send(sfd,result+sum,len-sum,0);
		sum+=ret;
	}
}
void searchUser(int sfd,MYSQL *conn)
{
	char name[20]={0};
	recv(sfd,name,sizeof(name),0);
	char result[10000]={0};
	char query[200]="select * from userTable where username like '";
	sprintf(query,"%s%s%s%s",query,"%",name,"%';");
	Mysqlop(conn,query,result);
	int len=strlen(result);
	int ret=0;
	int sum=0;
	send(sfd,&len,4,0);
	while(sum<len){
		ret=send(sfd,result+sum,len-sum,0);
		sum+=ret;
	}
}

void seeUser(int sfd,MYSQL *conn){
	char result[10000]={0};
	char query[40]="select * from userTable;";
	Mysqlop(conn,query,result);
	int len=strlen(result);
	int ret=0;
	int sum=0;
	send(sfd,&len,4,0);
	while(sum<len){
		ret=send(sfd,result+sum,len-sum,0);
		sum+=ret;
	}	
}
