#include"head.h"
#include "factory.h"

void tran_file(int new_fd,char *path,char *file){
	char buf[1000]={0};
	signal(SIGPIPE,SIG_IGN);
	if(NULL==file){
		printf("文件名为空！！\n");
		goto end;
	}
	int fd;
	sprintf(buf,"%s/%s",path,file);
	fd=open(buf,O_RDWR);
	bzero(buf,sizeof(buf));
	if(-1==fd){
		perror("open");
		buf[0]='N';
		send(new_fd,buf,1,0);
		goto end;
	}
	buf[0]='Y';
	send(new_fd,buf,1,0);
	printf("验证成功\n");
//	int len=strlen(file);
//	send_n(new_fd,file,strlen(file));
	struct stat buf1;
	int ret=fstat(fd,&buf1);
	if(-1==ret){
		perror("fstat");
		goto end;
	}
	int len=0;
	recv(new_fd,&len,4,0);
	//所需要传送的长度为buf1.st_size-len
	int tran_len=buf1.st_size-len;
	send(new_fd,&tran_len,4,0);//此文件的长度
	int sum=0;
	off_t t=(off_t)len;
	while((sum=sendfile(new_fd,fd,&t,buf1.st_size))>0);
	close(fd);
end:
	return;
}
