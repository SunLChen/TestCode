#include "head.h"

MYSQL *init(){
	MYSQL *conn;
	MYSQL_RES *res;
	MYSQL_ROW row;
	char *server="localhost";
	char *user="root";
	char *password="root";
	char *database="baiduYun";
	conn=mysql_init(NULL);
	if(!mysql_real_connect(conn,server,user,password,database,0,NULL,0))
	{
		printf("Error connecting to database:%s\n",mysql_error(conn));
	}else{
		printf("Connected...\n");
	}
	return conn;
}
//获取slat盐值
void get_salt(char *salt,char *ciphertext){
	int i,j;
	for(i=0,j=0;ciphertext[i]!=0&&j!=3;i++){
		if('$'==ciphertext[i])
			j++;
	}
	strncpy(salt,ciphertext,i-1);
}
int findSameUser(MYSQL *conn,char *user){

	char query[200]="select * from userTable where username='";
	sprintf(query,"%s%s%s",query,user,"';");
	MYSQL_RES *res;
	MYSQL_ROW row;
	int procatalog=0;
	int ret=0;
	int t=mysql_query(conn,query);
	if(t)
	{
		printf("Error making query:%s\n",mysql_error(conn));
	}else{
		res=mysql_use_result(conn);
		if(res)
		{
			while((row=mysql_fetch_row(res))!=NULL)
			{
				ret=2;
			}
		}
		mysql_free_result(res);
		return ret;
	}
}

int user_register(int new_fd,char **tempName){
	//用于随机生成salt值 
	//	struct spwd *sp;
	char name[20]={0};
	char salt[15];
	char p[50]={0};
	char buf[100]={0};
	bzero(buf,sizeof(buf));
	printf("准备接收\n");
	recv(new_fd,buf,sizeof(buf),0);
	//	printf("%s\n",buf);
	int j=0;
	for(int i=0;i<strlen(buf);i++){
		while(buf[i]!='\n'){
			name[i]=buf[i];
			i++;
		}
		j=0;
		i++;
		name[i]='\0';
		while(buf[i]!='\n'){
			salt[j]=buf[i];
			i++;
			j++;
		}
		salt[j]='\0';
		j=0;
		i++;
		while(buf[i]!='\0'){
			p[j]=buf[i];
			i++;
			j++;
		}
		p[j]='\0';
	}
	strcpy(*tempName,name);
	MYSQL *conn=init();
	int ret=findSameUser(conn,name);
	if(ret>0){
		mysql_close(conn);
		return -2;
	}
	struct tm *tmTime;
	char temp[1024]={0};
	char strTime[64]={0};
	time_t t1=time(NULL);
	tmTime=localtime(&t1);
	strftime(strTime,64,"%Y-%m-%d %H:%M:%S",tmTime);
	char query[200]="insert into userTable(username,saltFigure,ciphertext,Date) values('";
	sprintf(query,"%s%s%s%s%s%s%s%s%s%s%s",query,name,"',","'",salt,"',","'",p,"','",strTime,"')");
	char query1[200]="insert into fileTable(proCatalogue,fileName,fileType,user,path) values(";
	sprintf(query1,"%s%d%s%s%s%s%s%s%s%s%s",query1,0,",","'/',","'d',","'",name,"','","./home/",name,"')");
	int t=mysql_query(conn,query);
	if(t)
	{
		printf("Error making query:%s\n",mysql_error(conn));
		return -1;
	}else{
		printf("insert success\n");
	}
	t=mysql_query(conn,query1);
	if(t)
	{
		printf("Error making query:%s\n",mysql_error(conn));
		return -1;
	}else{
		printf("insert success\n");
	}
	mysql_close(conn);
	return 1;
}


int user_login(int new_fd,char **tempName){
	char name[20]={0};
	int len;
	int ret=recv(new_fd,&len,4,0);
	ret=recv(new_fd,name,len,0);
	name[strlen(name)]='\0';
	if(0>=ret){
		perror("recv");
		return 0;
	}
	char saltFigure[20]={0};
	char ciphertext[50]={0};
	char ciphertext1[50]={0};
	char query[200]="select * from userTable where username='";
	sprintf(query,"%s%s%s",query,name,"'");
	strcpy(*tempName,name);
	MYSQL *conn=init();	MYSQL_RES *res;MYSQL_ROW row;
	int t=mysql_query(conn,query);
	char flagUser='N';
	int permission=-1;
	if(t)
	{
		printf("Error making query:%s\n",mysql_error(conn));
	}else{
		res=mysql_use_result(conn);
		if(res){	
			while((row=mysql_fetch_row(res))!=NULL){
				flagUser='Y';
				strcpy(saltFigure,row[2]);
				strcpy(ciphertext,row[3]);
				permission=(*row[4]-48);//Ascii 码表
			}
		}
		mysql_free_result(res);	
		send(new_fd,&flagUser,1,0);
		mysql_close(conn);
		if(flagUser=='N')	goto end;
	}
	ret=send(new_fd,saltFigure,strlen(saltFigure),0);
	recv(new_fd,ciphertext1,sizeof(ciphertext1),0);
	if(strcmp(ciphertext1,ciphertext)==0){
		return permission;
	}else{
end:		
		permission=-1;
		return permission;
	}
}
//有问题，暂时停止
void mysql_select(char *catalog){
	MYSQL *conn=init();	
	char query[200]="select * from fileTable where filename='";
	sprintf(query,"%s%s%s",query,catalog,"'");	mysql_close(conn);
}
