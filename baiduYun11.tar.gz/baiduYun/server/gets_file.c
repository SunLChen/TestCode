#include "head.h"
#include "work_que.h"
void *thread_func_gets_file(void *pc)
{
	printf("进入传输线程\n");
	pgfile pf=(pgfile)pc;
	int sfd=pf->sfd;
	struct hostent *hent;
	//需用代码获取ip
//	char p[]="192.168.10.105";
	//随机生成端口号
//	printf("ip:%s\n",pf->IP);
	srand(time(NULL));
	//大于3000的端口号
	int port=rand()%10000+3000;
	int new_fd=socket(AF_INET,SOCK_STREAM,0);
	if(-1==new_fd){
		perror("socket");
	}
	struct sockaddr_in ser;
	bzero(&ser,sizeof(ser));
	ser.sin_family=AF_INET;
	ser.sin_port=htons(port);
	ser.sin_addr.s_addr=inet_addr(pf->IP);
	int ret=0;
	while((ret=bind(new_fd,(struct sockaddr*)&ser,sizeof(ser)))==-1){
		port=htons(rand()%10000+3000);
		ser.sin_port=htons(port);
	}
	printf("port1:%d\n",port);
	listen(new_fd,100);
	//发送端口号
	send(sfd,&port,4,0);
	sfd=accept(new_fd,NULL,NULL);
	ret=gets_file(sfd,pf->path,pf->filename,pf->user);
	close(sfd);
//	exit(ret);
}

int gets_file(int sfd,char *path,char *fileName,char *user){
	
	printf("进入getsfile\n");
	fTab tab;//定义fileTable的结构体
	MYSQL *conn=init();
	char sameName='N';
	long capacity[2]={0};
	//验证同名问题
	int ret=findSameName(conn,fileName,path);
	//传输文件
	int j=0;
	int flag;
	int fd;
	int sum=0;
	int writesum=0;
	int psum=0;
	int pipefd[2];  
	//
	if(ret>0){
		sameName='Y';
		send(sfd,&sameName,1,0);
		return -1;
	}
	//验证容量
	getsCapacity(conn,user,capacity);
	send(sfd,&sameName,1,0);
	char buf[1024]={0};

	char pathName[50]={0};
	char md5[33]={0};
	int len=0;
    ret=recv(sfd,&len,4,0);
	if(-1==ret){
		perror("recv");
		return -1;
	}
	ret=recv(sfd,md5,len,0);
	sprintf(pathName,"%s/%s",path,fileName);
	//	------------------验证md5是否存在----------------
	ret=getMD5(conn,md5,&tab);
	char oldpath[100]={0};
	sprintf(oldpath,"%s%s",".",tab.path+1);

	char flag1='N';
	if(ret==1){
			
			char newpath[100]={0};
			sprintf(newpath,"%s%s",".",pathName+1);
			struct stat statBuf;
			ret=stat(oldpath,&statBuf);
			len=statBuf.st_size;

			if(len+capacity[0]>capacity[1]){
				flag1='F';
			}else{
			ret=link(oldpath,newpath);
			if(-1==ret){
				perror("link");
				flag1='R';
			}else{
				flag1='C';
			}
		}
		send(sfd,&flag1,1,0);
		if(flag1=='R'){
			goto train;
		}
	}else{

		send(sfd,&flag1,1,0);

		if(-1==ret){
			perror("send");
			printf("传输失败！\n");
			return -1;
		}
train:	bzero(buf,sizeof(buf));
		recv(sfd,&len,4,0);
		if(capacity[0]+len>capacity[1]){
			flag1='F';
			send(sfd,&flag1,1,0);
		}else{
	    fd=open(pathName,O_RDWR|O_CREAT,0666);
		printf("pathName:%s\n",pathName);
		if(fd==-1){
			perror("open");
			return -1;
		}
		send(sfd,&flag1,1,0);

		ret = pipe(pipefd);  //创建管道  
		assert(ret != -1);  

		//将connfd上的客户端数据定向到管道中  
		while(sum<len){
			ret = splice(sfd, NULL, pipefd[1], NULL,  
					len, SPLICE_F_MORE | SPLICE_F_MOVE);  
			if(ret<=0&&sum<len){
				remove(pathName);
			}
			assert(ret != -1);  
			ret = splice(pipefd[0], NULL, fd, NULL,  
					len, SPLICE_F_MORE | SPLICE_F_MOVE);  
			assert(ret != -1);
			sum+=ret;
		}               
		 flag1='N';	
		close(fd);
		}
	}
	if(flag1!='Y'&&flag1!='F'){
		int procatalog=proCatalog(conn,path);
		putsFile(conn,procatalog,fileName,user,md5,path,len,capacity);
	}
	mysql_close(conn);
	return 0;
}
