#include "head.h"

void cd(int sfd,char **path,char *tempPath){
	char path1[1000];
	strcpy(path1,*path);
	if(tempPath!=NULL){
		if(tempPath[0]=='/'){
			sprintf(*path,"%s%s",*path,tempPath);	
		}else{
			if(strcmp(tempPath,".")!=0&&strcmp(tempPath,"..")!=0){				
				sprintf(*path,"%s/%s",*path,tempPath);
			}else if(0==strcmp(tempPath,"..")){
				int i,j,k=0;
				for(j=0;j<strlen(*path);j++){
					if((*path)[j]=='/'){
						k++;
					}
				}
				for(i=strlen(*path)-1;(*path)[i]!='/';i--);
				k--;
				if(k>=2){
					(*path)[i]='\0';
				}
			}
		}
	}
	if(opendir(*path)==NULL){
		char *buf="你所要进入的是可能不是目录！";
		send_n(sfd,buf,strlen(buf));
		strcpy(*path,path1);
		return;
	}
	send_n(sfd,*path,strlen(*path));
}



void ls(int sfd,char *path){
	DIR *dp=opendir(path);
	if(NULL==dp){
		perror("opendir");
		return;
	}
	struct dirent *p;
	struct stat statBuf;
	char pathBuf[1024]={0};
	int ret;
	struct tm *tmTime;
	char temp[1024]={0};
	char strTime[64];
	while((p=readdir(dp))!=NULL){
		sprintf(temp,"%s/%s",path,p->d_name);
		ret=stat(temp,&statBuf);
		tmTime=localtime(&statBuf.st_mtime);
		strftime(strTime,64,"%Y-%m-%d %H:%M:%S",tmTime);
		if(strcmp(p->d_name,".")==0||strcmp(p->d_name,"..")==0)
			continue;
		if(p->d_type==4)
		{	
			sprintf(pathBuf,"%s    %s    %s    %s\n",pathBuf,strTime,"d",p->d_name);
		}else{
			sprintf(pathBuf,"%s    %s    %s    %s    %8ld B\n",pathBuf,strTime,"f",p->d_name,statBuf.st_size);
		}
	}
	pathBuf[strlen(pathBuf)]='\0';
	if(strlen(pathBuf)==0){
		strcpy(pathBuf,"亲，该目录没有文件！！");
	}
	send(sfd,pathBuf,strlen(pathBuf),0);
}

void pwd(int sfd,char *path){
	send(sfd,path,strlen(path),0);
}

void mkdir_c(int sfd,char *path,char *dirname){
	char buf[1000]={0};
	sprintf(buf,"%s/%s%c",path,dirname,'\0');
	
	if(opendir(buf)==NULL){
		printf("%s\n",buf);
		int ret=mkdir(buf,0777);
		if(-1==ret){
			perror("mkdir");
			return;
		}

	}
	strcpy(buf,"创建成功！");
	send(sfd,buf,strlen(buf),0);
}

void remove_c(int sfd,char *path,char *filename,char *user){	
	char buf[1000]={0};
	char flag='N';
	if(strlen(filename)==0){
		strcpy(buf,"参数错误");
		send(sfd,buf,strlen(buf),0);
	}
	
	struct stat statBuf;
	sprintf(buf,"%s/%s%c",path,filename,'\0');	
	
	int ret=stat(buf,&statBuf);
	if(ret==-1){
		flag='N';
	}else{
		if(S_ISREG(statBuf.st_mode)){
			flag='F';
			bzero(buf,sizeof(buf));
			MYSQL *conn=init();
			sprintf(buf,"%s/%s%c",path,filename,'\0');	
			remove_file(conn,filename,buf,user);
			mysql_close(conn);
		}
		if(S_ISDIR(statBuf.st_mode)){
			flag='D';
		}
	}
	if(flag!='N'){
		int ret=remove(buf);
		if(-1==ret){
		strcpy(buf,"你所要删除的文件可能找不到或是有文件的目录！");
		send(sfd,buf,strlen(buf),0);
		return;
		}
		strcpy(buf,"删除成功");
		send(sfd,buf,strlen(buf),0);
	}else{
	
		strcpy(buf,"输入了错误的文件名");
		send(sfd,buf,strlen(buf),0);
	}
}
//下载文件
void gets(int sfd,char *path,char *filename){
	
	char buf[1000]={0};
	if(strlen(filename)==0){
		strcpy(buf,"参数错误");
		send(sfd,buf,strlen(buf),0);
	}
	sprintf(buf,"%s/%s%c",path,filename,'\0');
		
}

void search_c(int sfd,char *filename,char *user){
	MYSQL *conn=init();
	searchFile(conn,sfd,filename,user);
	mysql_close(conn);
}

void see_cap(int sfd,char *user){
	MYSQL *conn=init();
	long capacity[2]={0};
	getsCapacity(conn,user,capacity);
	char msg[20]={0};
	sprintf(msg,"%ld %ld",capacity[0],capacity[1]);
	int ret=0;
	int sum=0;
	int len=strlen(msg);
	while(sum<len){
		ret=send(sfd,msg+sum,len-sum,0);
		sum+=ret;
	}
}
