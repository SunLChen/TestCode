#include "head.h"

void admin(int sfd){
	int op=0;
	MYSQL *conn=init();
start:
	recv(sfd,&op,4,0);
	switch(op){
		case 1:searchUser(sfd,conn); break;
		case 2:seeUser(sfd,conn); break;
		case 3:deleteUser(sfd,conn);break;
		case 4:updateUserCapacity(sfd,conn);break;
		default: goto start;	
	}
	op=0;
	goto start;
}


